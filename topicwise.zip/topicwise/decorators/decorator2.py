# This simplest decorator does nothing to the function being decorated. Such
# minimal decorators can occasionally be used as a kind of code markers.
def super_secret_function(f):
    print("Inside decorator")
    return f

@super_secret_function
def my_function():
    print("This is my secret function.")

