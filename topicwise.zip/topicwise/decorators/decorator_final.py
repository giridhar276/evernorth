
def hello(func):
    print('hello')
    return func


@hello
def add(a,b):
    return a + b


add(10,20)
