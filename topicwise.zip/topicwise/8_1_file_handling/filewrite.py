#!/usr/bin/python

mystring = "This is my first line"

fobj = open("newdemo.txt","w")
fobj.write(mystring)
fobj.close()
 
