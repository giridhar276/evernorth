import boto3

region = 'ap-south-1'
ec2_con_re = boto3.resource('ec2',region

for instance in ec2_con_re.instances.all():
    print(each.id)
    print(each.attach_classic_link_vpc
