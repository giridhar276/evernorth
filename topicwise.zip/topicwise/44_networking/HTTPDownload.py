#
#import urllib
from urllib.request import urlretrieve
print("starting download")

urlretrieve("http://ebook-dl.com/md5/ef59e4a4d835b047d025bdad1895de4c.pdf", "ebook1.pdf")

print("completed")


# link : http://ebook-dl.com/book/27547

# file download page : http://ebook-dl.com/md5/ef59e4a4d835b047d025bdad1895de4c.pdf

