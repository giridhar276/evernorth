
from external import make_pretty

@make_pretty
def ordinary():
    print("I am ordinary")


ordinary()
