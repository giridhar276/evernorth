import urllib.request

wp = urllib.request.urlopen("http://google.com")
print(wp)

'''
pw = wp.read()
print(pw)
'''
