import requests
import json
r = requests.get('https://api.github.com', auth=('giridhar276','b72a61b545bacdb62a0155bb7ac3514f20c0620a'))
print(r.status_code)


info = json.loads(r.text)
for key in info:
    print(key.ljust(20) , ":"  , info[key])
