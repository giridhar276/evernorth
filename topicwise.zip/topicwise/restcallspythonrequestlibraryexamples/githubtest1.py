## display the current user repositories in github

from github import Github

# First create a Github instance:

# using username and password
#g = Github("giridhar276@gmail.com", "Nolimits1@")

#print(g)

g = Github("8f7dd3f65c4c60f1b57f8ec8f15b692fe28d70cb ")

## all the repos
#for repo in g.get_repos():
#    print(repo)


for repo in g.get_user().get_repos():
    print(repo.name)
