 
  
import requests



server = "https://api.github.com"
url = server + "/gists"
endpoint = "https://api.github.com/users/giridhar276/repos"

r = requests.get(endpoint, auth=('giridhar276','696834938f2222a5d55a42116f5be58489172799'))


print(r.text[0])
