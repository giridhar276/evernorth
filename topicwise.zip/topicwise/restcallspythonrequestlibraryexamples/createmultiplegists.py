import os   
import requests
import json
from requests.auth import HTTPBasicAuth
server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"
print("checking ", url, "using user:", user)

local_file = "githubtest0.py"
with open(local_file) as fh:
    mydata = fh.read()
files = {
    "description": "2nd test",
    "public": "true",
    "user" : user,
    "files" : {}
}
for file in os.listdir():
    with open(file) as fobj:
        content = fobj.read()     
        files["files"].update({file :{ "content":content}})
r1 = requests.post(url, data=json.dumps(files), auth=HTTPBasicAuth(user,'5e42667d35538cb903f14852ddd841296bbbafd1'))
print(r1.json())
