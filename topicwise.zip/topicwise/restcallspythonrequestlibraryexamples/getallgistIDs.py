 
    
import requests
import json
 


r = requests.get('https://api.github.com/users/giridharpython/gists', \
                 auth=('giridharpython','899c4e5f45afb059bcd45d76f95855ce1cbdd220'))
 

info = json.loads(r.text)

#print(r.text)

for item in info:
    for key in item:
        print(key.ljust(10), item[key])

    print("------------------------------------")


