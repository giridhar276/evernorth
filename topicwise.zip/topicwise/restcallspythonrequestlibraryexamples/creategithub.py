import requests
import json
from requests.auth import HTTPBasicAuth

server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"
#passwd = getpass.getpass('Password:')
print("checking ", url, "using user:", user)

local_file = "accessingdatabase.py"

description  = local_file.split(".")[0]
with open(local_file) as fh:
    mydata = fh.read()
files = {
    "description": description,
    "public": "true",
    "user" : user,
    "files": {
    local_file : {
    "content": mydata
        }
      }
}
r1 = requests.post(url, data=json.dumps(files), auth=(user,'99c4e5f45afb059bcd45d76f95855ce1cbdd220'))
print(r1.json())
