from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()

try:
    driver.get("https://practicetestautomation.com/practice-test-login/")
    driver.find_element(By.ID, "username").send_keys("wronguser")
    driver.find_element(By.ID, "password").send_keys("wrongpass")
    driver.find_element(By.ID, "submit").click()

    error = driver.find_element(By.ID, "error").text
    assert "Your username is invalid!" in error or "Your password is invalid!" in error
    print("Error displayed correctly on invalid login")

except Exception as e:
    print("Test failed:", e)
finally:
    time.sleep(2)
    driver.quit()
