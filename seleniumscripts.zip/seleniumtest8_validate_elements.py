from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()

try:
    driver.get("https://practicetestautomation.com/practice-test-login/")
    driver.find_element(By.ID, "username").send_keys("student")
    driver.find_element(By.ID, "password").send_keys("Password123")
    driver.find_element(By.ID, "submit").click()
    time.sleep(2)

    assert "logged-in-successfully" in driver.current_url
    assert "Logged In Successfully" in driver.find_element(By.TAG_NAME, "h1").text
    assert driver.find_element(By.LINK_TEXT, "Log out").is_displayed()
    paragraph = driver.find_element(By.TAG_NAME, "p").text
    assert "Congratulations" in paragraph
    print("All post-login validations passed")

except Exception as e:
    print("Validation failed:", e)
finally:
    time.sleep(2)
    driver.quit()
