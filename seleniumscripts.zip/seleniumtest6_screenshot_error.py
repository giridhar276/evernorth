from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time

# Initialize the driver
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.amazon.in")