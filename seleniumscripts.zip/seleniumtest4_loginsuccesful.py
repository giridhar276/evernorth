
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Set up WebDriver (use your own driver path if needed)
driver = webdriver.Chrome()  # Make sure chromedriver is in PATH
driver.maximize_window()

try:
    # Open login page
    driver.get("https://practicetestautomation.com/practice-test-login/")

    # Fill in username and password
    driver.find_element(By.ID, "username").send_keys("student")
    driver.find_element(By.ID, "password").send_keys("Password123")

    # Click the submit button
    driver.find_element(By.ID, "submit").click()

    # Wait until the success message appears
    success_message = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.TAG_NAME, "h1"))
    )

    # Validate successful login
    if "Logged In Successfully" in success_message.text:
        print("Login successful!")

        # Optional: Click logout
        logout_button = driver.find_element(By.LINK_TEXT, "Log out")
        logout_button.click()
        print("Logged out successfully!")
    else:
        print("Login failed!")

except Exception as e:
    print("Error:", e)

finally:
    time.sleep(2)
    driver.quit()
