from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time


# Start the driver
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.amazon.in")

# Search for the product
search_box = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.ID, "twotabsearchtextbox"))
)
search_box.send_keys("wireless mouse")
driver.find_element(By.ID, "nav-search-submit-button").click()

# Wait for product results to load
WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.CSS_SELECTOR, "div.s-main-slot"))
)

# Scroll to the bottom to load more products (if lazy-loaded)
#driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
time.sleep(2)  # wait for dynamic content to load

# Extract product titles
product_titles = driver.find_elements(By.XPATH, "//div[@data-component-type='s-search-result']//h2//span")

print("\nProduct Titles Found:")
for idx, title in enumerate(product_titles, 1):
    print(f"{idx}. {title.text}")

driver.quit()
