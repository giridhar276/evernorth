# Example 1: Search for a Product
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.amazon.in")

search_box = driver.find_element(By.ID, "twotabsearchtextbox")
search_box.send_keys("wireless mouse")
driver.find_element(By.ID, "nav-search-submit-button").click()
time.sleep(2)
driver.quit()