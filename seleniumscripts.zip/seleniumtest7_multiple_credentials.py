from selenium import webdriver
from selenium.webdriver.common.by import By
import time

credentials = [
    ("student", "Password123"),     # Valid
    ("student", "wrongpass"),       # Invalid
    ("invalid", "Password123"),     # Invalid
    ("", "Password123"),            # Blank username
    ("student", ""),                # Blank password
]

driver = webdriver.Chrome()
driver.maximize_window()

for username, password in credentials:
    driver.get("https://practicetestautomation.com/practice-test-login/")
    driver.find_element(By.ID, "username").send_keys(username)
    driver.find_element(By.ID, "password").send_keys(password)
    driver.find_element(By.ID, "submit").click()
    time.sleep(1)

    if "logged-in-successfully" in driver.current_url:
        print(f" Login success → ({username}, {password})")
        driver.find_element(By.LINK_TEXT, "Log out").click()
    else:
        print(f"Login failed → ({username}, {password})")
    time.sleep(1)

driver.quit()
