from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
driver.get("https://automationexercise.com")
driver.maximize_window()

# Navigate to Signup/Login
driver.find_element(By.LINK_TEXT, "Signup / Login").click()

# Enter name and email
driver.find_element(By.NAME, "name").send_keys("Test User")
driver.find_element(By.XPATH, "//input[@data-qa='signup-email']").send_keys("testuser123@example.com")
driver.find_element(By.XPATH, "//button[text()='Signup']").click()

# Fill details
WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.ID, "id_gender1"))).click()
driver.find_element(By.ID, "password").send_keys("testpass123")
driver.find_element(By.ID, "days").send_keys("10")
driver.find_element(By.ID, "months").send_keys("March")
driver.find_element(By.ID, "years").send_keys("1990")
driver.find_element(By.ID, "first_name").send_keys("Test")
driver.find_element(By.ID, "last_name").send_keys("User")
driver.find_element(By.ID, "address1").send_keys("123 Testing Lane")
driver.find_element(By.ID, "state").send_keys("Test State")
driver.find_element(By.ID, "city").send_keys("Test City")
driver.find_element(By.ID, "zipcode").send_keys("123456")
driver.find_element(By.ID, "mobile_number").send_keys("9876543210")
driver.find_element(By.XPATH, "//button[text()='Create Account']").click()

# Confirm account created
assert "ACCOUNT CREATED!" in driver.page_source
print("User account created successfully.")
driver.quit()
